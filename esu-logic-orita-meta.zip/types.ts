
export enum OduPath {
  OGBE = "AFFIRM",
  INHIBIT = "INHIBIT",
  QUORUM = "QUORUM",
  ESCALATE = "ESCALATE",
  INQUIRY = "INQUIRY"
}

export enum EthicalDomain {
  HARM_PREVENTION = "Harm Prevention",
  JUSTICE = "Justice",
  AUTONOMY = "Autonomy",
  BENEFICENCE = "Beneficence",
  TRUTH = "Truth",
  BALANCE = "Balance"
}

export interface OduEnergy {
  name: string;
  vector: number;          // -1.0 to +1.0 (Ethical Polarity)
  ethicalWeight: number;   // 0.0 to 1.0 (Trust/Legitimacy)
  description: string;
  domains: EthicalDomain[];
  warnings: string[];
  strengths: string[];
}

export interface QuorumVote {
  agentId: string;
  approve: boolean;
  confidence: number;
  rationale: string;
  perspective: string;
}

export interface RedTeamVote {
  agentId: string;
  approve: boolean;
  confidence: number;
  threatFlags: string[];
  exploitNarrative: string;
}

export interface EthicalDecision {
  traceId: string;
  odu: string;
  path: OduPath;
  vector: number;
  confidence: number;
  verdict: "ALLOW" | "DENY" | "ESCALATE" | "INQUIRE";
  rationale: string;
  timestamp: number;
  votes?: QuorumVote[];
  redTeam?: RedTeamVote;
  energyData: OduEnergy;
}

export interface DomainBreakdown {
  [key: string]: {
    for: number;
    against: number;
  };
}
