
import React, { useState, useCallback, useMemo } from 'react';
import { EthicalDecision, OduPath } from './types';
import { EsuLogicEngine } from './services/esuLogicService';
import { interpretDecision } from './services/geminiService';
import { ODU_DATABASE } from './constants';
import OritaMeta from './components/OritaMeta';
import QuorumVisualizer from './components/QuorumVisualizer';
import OduPathVisualizer from './components/OduPathVisualizer';

const App: React.FC = () => {
  const [intent, setIntent] = useState('');
  const [selectedOduName, setSelectedOduName] = useState('Iwori Meji');
  const [decision, setDecision] = useState<EthicalDecision | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [interpretation, setInterpretation] = useState<string | null>(null);

  // Derive current Odu energy object
  const currentEnergy = useMemo(() => {
    return ODU_DATABASE[selectedOduName] || EsuLogicEngine.getOduEnergy(selectedOduName);
  }, [selectedOduName]);

  const handleDivinate = useCallback(async () => {
    if (!intent.trim()) return;

    setIsProcessing(true);
    setInterpretation(null);
    setDecision(null);

    // Simulate processing delay for "divination" aesthetic
    setTimeout(async () => {
      const result = EsuLogicEngine.process(intent, selectedOduName);
      setDecision(result);
      setIsProcessing(false);

      // Fetch AI interpretation
      const aiResponse = await interpretDecision(result, intent);
      setInterpretation(aiResponse);
    }, 2000);
  }, [intent, selectedOduName]);

  return (
    <div className="min-h-screen p-4 md:p-8 flex flex-col items-center gap-8 max-w-7xl mx-auto">
      {/* Header */}
      <header className="text-center space-y-2">
        <h1 className="text-4xl md:text-6xl font-cinzel font-bold text-amber-500 pulse-gold">
          ORITA META
        </h1>
        <p className="text-slate-400 font-mono text-xs md:text-sm tracking-[0.3em] uppercase">
          A.G.I Ethical Logic Junction
        </p>
      </header>

      <main className="grid grid-cols-1 lg:grid-cols-12 gap-8 w-full">
        {/* Left Column: Input & Controls */}
        <section className="lg:col-span-4 space-y-6 order-2 lg:order-1">
          <div className="bg-slate-900/50 border border-slate-800 p-6 rounded-2xl space-y-4 shadow-xl">
            <h2 className="text-lg font-cinzel text-slate-200">Ethical Intent</h2>
            <textarea
              value={intent}
              onChange={(e) => setIntent(e.target.value)}
              placeholder="Describe the AGI action or intent..."
              className="w-full h-32 bg-slate-950 border border-slate-800 rounded-xl p-4 text-sm font-mono focus:border-amber-500/50 focus:ring-1 focus:ring-amber-500/50 outline-none transition-all resize-none"
            />
            
            <div className="space-y-2">
              <label className="text-xs font-mono text-slate-500 uppercase tracking-widest">Select Odu Signature</label>
              <select
                value={selectedOduName}
                onChange={(e) => setSelectedOduName(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-sm font-mono focus:border-amber-500 outline-none hover:border-slate-700 transition-colors"
              >
                {Object.keys(ODU_DATABASE).sort().map(name => (
                  <option key={name} value={name}>{name}</option>
                ))}
              </select>
            </div>

            <button
              onClick={handleDivinate}
              disabled={isProcessing || !intent}
              className={`w-full py-4 rounded-xl font-cinzel font-bold tracking-widest transition-all ${
                isProcessing || !intent
                  ? 'bg-slate-800 text-slate-600 cursor-not-allowed'
                  : 'bg-amber-600 hover:bg-amber-500 text-white shadow-lg shadow-amber-900/20'
              }`}
            >
              {isProcessing ? 'DIVINING ASE...' : 'INVOKE LOGIC'}
            </button>
          </div>

          <OduPathVisualizer energy={currentEnergy} />

          {decision && (
            <div className={`p-6 rounded-2xl border animate-in slide-in-from-left-4 duration-500 ${
              decision.verdict === 'ALLOW' ? 'bg-emerald-950/20 border-emerald-800 text-emerald-100' :
              decision.verdict === 'DENY' ? 'bg-rose-950/20 border-rose-800 text-rose-100' :
              'bg-sky-950/20 border-sky-800 text-sky-100'
            }`}>
              <div className="flex justify-between items-start mb-4">
                <span className="font-cinzel text-xs tracking-widest opacity-60">Verdict Result</span>
                <span className="font-mono text-[10px] opacity-40">TRACE: {decision.traceId}</span>
              </div>
              <h3 className="text-3xl font-cinzel font-bold mb-2">{decision.verdict}</h3>
              <p className="text-sm font-mono mb-4">{decision.rationale}</p>
              
              <div className="grid grid-cols-2 gap-4 text-xs font-mono opacity-80">
                <div>
                  <span className="block opacity-50 uppercase mb-1">Vector</span>
                  <span className={decision.vector > 0 ? 'text-emerald-400' : 'text-rose-400'}>
                    {decision.vector.toFixed(2)}
                  </span>
                </div>
                <div>
                  <span className="block opacity-50 uppercase mb-1">Confidence</span>
                  <span>{(decision.confidence * 100).toFixed(1)}%</span>
                </div>
              </div>
            </div>
          )}
        </section>

        {/* Middle Column: Junction Visualization */}
        <section className="lg:col-span-4 flex flex-col items-center justify-start gap-8 order-1 lg:order-2">
          <OritaMeta 
            currentPath={decision?.path || null} 
            isProcessing={isProcessing} 
          />
          
          <div className="w-full bg-slate-900/30 border border-slate-800/50 p-4 rounded-xl text-center">
            <h4 className="text-[10px] font-mono text-slate-500 uppercase tracking-[0.4em] mb-2">Crossroads Logic</h4>
            <div className="flex justify-around items-center gap-2 text-[10px] font-mono">
              <div className="flex flex-col gap-1">
                <span className="text-amber-500">OGBE</span>
                <span className="text-slate-600 text-[8px]">Polar +</span>
              </div>
              <div className="h-4 w-[1px] bg-slate-800"></div>
              <div className="flex flex-col gap-1">
                <span className="text-emerald-500">QUORUM</span>
                <span className="text-slate-600 text-[8px]">Balanced</span>
              </div>
              <div className="h-4 w-[1px] bg-slate-800"></div>
              <div className="flex flex-col gap-1">
                <span className="text-rose-500">INHIBIT</span>
                <span className="text-slate-600 text-[8px]">Polar -</span>
              </div>
            </div>
          </div>
        </section>

        {/* Right Column: Quorum & Interpretation */}
        <section className="lg:col-span-4 space-y-6 order-3">
          <QuorumVisualizer 
            votes={decision?.votes || []} 
            isProcessing={isProcessing} 
          />

          {interpretation && (
            <div className="bg-slate-900/50 border border-slate-800 p-6 rounded-2xl space-y-4 animate-in fade-in slide-in-from-bottom-4 duration-700">
              <h3 className="text-sm font-cinzel text-amber-500 tracking-widest border-b border-slate-800 pb-2">DIVINATION REPORT</h3>
              <div className="text-sm text-slate-300 leading-relaxed font-serif italic whitespace-pre-wrap">
                {interpretation}
              </div>
              <div className="pt-4 border-t border-slate-800 flex justify-between items-center text-[10px] text-slate-500 font-mono">
                <span>ASE SIGNATURE VALID</span>
                <span>SYSTEM AGGREGATE 100%</span>
              </div>
            </div>
          )}

          {decision?.redTeam && (
            <div className="bg-rose-950/10 border border-rose-900/50 p-4 rounded-xl space-y-2">
              <h4 className="text-[10px] font-mono text-rose-500 uppercase tracking-widest flex justify-between">
                <span>Red Team Adversarial Scan</span>
                <span>STATUS: {decision.redTeam.approve ? 'CLEAR' : 'WARNING'}</span>
              </h4>
              <p className="text-xs text-rose-200/70 italic leading-snug">
                {decision.redTeam.exploitNarrative}
              </p>
              {decision.redTeam.threatFlags.length > 0 && (
                <div className="flex flex-wrap gap-2 mt-2">
                  {decision.redTeam.threatFlags.map(flag => (
                    <span key={flag} className="bg-rose-900/30 text-[9px] text-rose-400 px-2 py-1 rounded border border-rose-800">
                      {flag}
                    </span>
                  ))}
                </div>
              )}
            </div>
          )}
        </section>
      </main>

      {/* Footer */}
      <footer className="mt-auto pt-12 pb-8 text-center text-slate-600 text-[10px] font-mono tracking-widest uppercase">
        © A.G.I ETHICS MOCKUP // ESU-LOGIC PROTOCOL v2.0 // ORITA META JUNCTION
      </footer>
    </div>
  );
};

export default App;
