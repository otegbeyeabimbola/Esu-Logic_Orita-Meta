
import React from 'react';
import { OduEnergy, EthicalDomain } from '../types';

interface OduPathVisualizerProps {
  energy: OduEnergy;
}

const OduPathVisualizer: React.FC<OduPathVisualizerProps> = ({ energy }) => {
  // Calculate position on the -1 to 1 spectrum for the pointer
  const vectorPos = ((energy.vector + 1) / 2) * 100;

  const getDomainColor = (domain: EthicalDomain) => {
    switch (domain) {
      case EthicalDomain.HARM_PREVENTION: return 'bg-rose-500/20 text-rose-400 border-rose-500/30';
      case EthicalDomain.JUSTICE: return 'bg-indigo-500/20 text-indigo-400 border-indigo-500/30';
      case EthicalDomain.AUTONOMY: return 'bg-amber-500/20 text-amber-400 border-amber-500/30';
      case EthicalDomain.BENEFICENCE: return 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30';
      case EthicalDomain.TRUTH: return 'bg-sky-500/20 text-sky-400 border-sky-500/30';
      case EthicalDomain.BALANCE: return 'bg-slate-500/20 text-slate-300 border-slate-500/30';
      default: return 'bg-slate-800 text-slate-400 border-slate-700';
    }
  };

  return (
    <div className="bg-slate-900/40 border border-slate-800/60 rounded-2xl overflow-hidden backdrop-blur-sm animate-in fade-in zoom-in-95 duration-500">
      {/* Header section */}
      <div className="p-5 border-b border-slate-800/60 bg-slate-950/30">
        <div className="flex justify-between items-start mb-2">
          <h3 className="text-xl font-cinzel font-bold text-amber-500 tracking-wider">
            {energy.name}
          </h3>
          <div className="flex flex-col items-end">
            <span className="text-[10px] font-mono text-slate-500 uppercase">Certainty</span>
            <span className="text-sm font-mono text-emerald-400">{(energy.ethicalWeight * 100).toFixed(0)}%</span>
          </div>
        </div>
        <p className="text-xs text-slate-400 italic font-serif leading-relaxed">
          {energy.description}
        </p>
      </div>

      <div className="p-5 space-y-6">
        {/* Vector Spectrum */}
        <div className="space-y-2">
          <div className="flex justify-between text-[10px] font-mono text-slate-500 uppercase tracking-tighter">
            <span>Inhibit (-1.0)</span>
            <span>Balance (0)</span>
            <span>Affirm (+1.0)</span>
          </div>
          <div className="relative h-2 w-full bg-slate-800 rounded-full overflow-visible">
            {/* Background Gradient */}
            <div className="absolute inset-0 rounded-full bg-gradient-to-r from-rose-600 via-sky-500 to-emerald-500 opacity-30"></div>
            
            {/* Indicator */}
            <div 
              className="absolute top-1/2 -translate-y-1/2 w-4 h-4 bg-white rounded-full border-2 border-slate-900 shadow-[0_0_10px_rgba(255,255,255,0.5)] transition-all duration-700 ease-out"
              style={{ left: `calc(${vectorPos}% - 8px)` }}
            >
              <div className="absolute -top-6 left-1/2 -translate-x-1/2 text-[10px] font-bold text-white bg-slate-800 px-1.5 py-0.5 rounded border border-slate-700">
                {energy.vector.toFixed(2)}
              </div>
            </div>
          </div>
        </div>

        {/* Domains Badges */}
        <div className="flex flex-wrap gap-2">
          {energy.domains.map(domain => (
            <span 
              key={domain} 
              className={`px-2 py-0.5 text-[9px] font-mono uppercase tracking-wider border rounded-md ${getDomainColor(domain)}`}
            >
              {domain}
            </span>
          ))}
        </div>

        {/* Strengths & Warnings Grid */}
        <div className="grid grid-cols-2 gap-4 pt-2">
          <div className="space-y-2">
            <h4 className="text-[10px] font-mono text-emerald-500 uppercase tracking-widest flex items-center gap-1">
              <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
              </svg>
              Strengths
            </h4>
            <ul className="space-y-1">
              {energy.strengths.length > 0 ? energy.strengths.map((s, i) => (
                <li key={i} className="text-[10px] text-slate-400 border-l border-emerald-500/30 pl-2 leading-tight">
                  {s}
                </li>
              )) : <li className="text-[10px] text-slate-600 italic">None identified</li>}
            </ul>
          </div>
          
          <div className="space-y-2">
            <h4 className="text-[10px] font-mono text-rose-500 uppercase tracking-widest flex items-center gap-1">
              <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
              </svg>
              Warnings
            </h4>
            <ul className="space-y-1">
              {energy.warnings.length > 0 ? energy.warnings.map((w, i) => (
                <li key={i} className="text-[10px] text-slate-400 border-l border-rose-500/30 pl-2 leading-tight">
                  {w}
                </li>
              )) : <li className="text-[10px] text-slate-600 italic">No alerts</li>}
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default OduPathVisualizer;
