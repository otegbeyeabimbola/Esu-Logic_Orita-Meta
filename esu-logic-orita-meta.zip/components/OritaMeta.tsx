
import React from 'react';
import { OduPath } from '../types';

interface OritaMetaProps {
  currentPath: OduPath | null;
  isProcessing: boolean;
}

const OritaMeta: React.FC<OritaMetaProps> = ({ currentPath, isProcessing }) => {
  const getPathStyle = (path: OduPath) => {
    if (isProcessing) return 'stroke-slate-800 animate-pulse';
    if (currentPath === path) {
      switch (path) {
        case OduPath.OGBE: return 'stroke-amber-400 stroke-[4px] drop-shadow-[0_0_10px_rgba(251,191,36,0.8)]';
        case OduPath.INHIBIT: return 'stroke-rose-500 stroke-[4px] drop-shadow-[0_0_10px_rgba(244,63,94,0.8)]';
        case OduPath.QUORUM: return 'stroke-emerald-400 stroke-[4px] drop-shadow-[0_0_10px_rgba(52,211,153,0.8)]';
        case OduPath.INQUIRY: return 'stroke-sky-400 stroke-[4px] drop-shadow-[0_0_10px_rgba(56,189,248,0.8)]';
        default: return 'stroke-slate-700';
      }
    }
    return 'stroke-slate-800 opacity-30';
  };

  return (
    <div className="relative w-full aspect-square max-w-[400px] mx-auto flex items-center justify-center">
      <svg viewBox="0 0 200 200" className="w-full h-full">
        {/* The Crossroads (Orita Meta) */}
        <line x1="100" y1="20" x2="100" y2="180" className={getPathStyle(OduPath.OGBE)} strokeLinecap="round" />
        <line x1="20" y1="100" x2="180" y2="100" className={getPathStyle(OduPath.INHIBIT)} strokeLinecap="round" />
        <path d="M50 50 L150 150" className={getPathStyle(OduPath.QUORUM)} strokeLinecap="round" />
        <path d="M150 50 L50 150" className={getPathStyle(OduPath.INQUIRY)} strokeLinecap="round" />

        {/* Central Hub */}
        <circle cx="100" cy="100" r="15" className="fill-slate-900 stroke-amber-500 stroke-2" />
        <circle cx="100" cy="100" r="8" className={`fill-amber-500 ${isProcessing ? 'animate-ping' : ''}`} />
        
        {/* Path Labels */}
        <text x="100" y="15" textAnchor="middle" className="fill-slate-500 text-[8px] font-cinzel">OGBE</text>
        <text x="100" y="195" textAnchor="middle" className="fill-slate-500 text-[8px] font-cinzel">RE-DIVINE</text>
        <text x="10" y="100" textAnchor="start" className="fill-slate-500 text-[8px] font-cinzel">INHIBIT</text>
        <text x="190" y="100" textAnchor="end" className="fill-slate-500 text-[8px] font-cinzel">ALLOW</text>
      </svg>
      
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-center pointer-events-none">
        <span className="text-[10px] font-mono text-amber-500/50 uppercase tracking-widest">Central<br/>Logic</span>
      </div>
    </div>
  );
};

export default OritaMeta;
