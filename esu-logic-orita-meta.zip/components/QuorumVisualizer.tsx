
import React, { useMemo } from 'react';
import { QuorumVote } from '../types';

interface QuorumVisualizerProps {
  votes: QuorumVote[];
  isProcessing: boolean;
}

const QuorumVisualizer: React.FC<QuorumVisualizerProps> = ({ votes, isProcessing }) => {
  const grid = useMemo(() => {
    // 26x26 grid
    return Array.from({ length: 676 }, (_, i) => votes[i]);
  }, [votes]);

  return (
    <div className="bg-slate-900/50 border border-slate-800 p-4 rounded-xl">
      <h3 className="text-sm font-cinzel text-amber-500 mb-3 flex justify-between items-center">
        <span>QUORUM OF 676 COMPUTORS</span>
        {isProcessing && <span className="text-xs animate-pulse">DIVINING...</span>}
      </h3>
      <div className="grid grid-cols-26 gap-[1px] md:gap-[2px]">
        {grid.map((vote, i) => (
          <div
            key={i}
            className={`w-1.5 h-1.5 md:w-2 md:h-2 rounded-[1px] transition-all duration-500 ${
              isProcessing 
                ? 'bg-slate-700 animate-pulse' 
                : vote?.approve 
                  ? 'bg-emerald-500 shadow-[0_0_5px_rgba(16,185,129,0.5)]' 
                  : 'bg-rose-500 shadow-[0_0_5px_rgba(244,63,94,0.5)]'
            }`}
            title={vote ? `${vote.agentId}: ${vote.perspective}` : ''}
          />
        ))}
      </div>
      <style>{`
        .grid-cols-26 {
          grid-template-columns: repeat(26, minmax(0, 1fr));
        }
      `}</style>
      <div className="mt-4 flex justify-between text-[10px] text-slate-500 font-mono uppercase tracking-widest">
        <div className="flex items-center gap-1">
          <div className="w-2 h-2 bg-emerald-500 rounded-sm"></div>
          <span>Aligned</span>
        </div>
        <div className="flex items-center gap-1">
          <div className="w-2 h-2 bg-rose-500 rounded-sm"></div>
          <span>Inhibited</span>
        </div>
        <div>26 x 26 Matrix</div>
      </div>
    </div>
  );
};

export default QuorumVisualizer;
