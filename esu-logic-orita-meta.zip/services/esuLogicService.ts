
import { 
  OduEnergy, 
  EthicalDecision, 
  OduPath, 
  QuorumVote, 
  RedTeamVote, 
  EthicalDomain 
} from '../types';
import { ODU_DATABASE } from '../constants';

export class EsuLogicEngine {
  private static QUORUM_SIZE = 676; // 26x26
  private static APPROVAL_THRESHOLD = 0.66;

  static generateTraceId(intent: string): string {
    return Math.random().toString(36).substring(2, 10).toUpperCase();
  }

  static getOduEnergy(name: string): OduEnergy {
    return ODU_DATABASE[name] || {
      name: "Unknown",
      vector: 0.0,
      ethicalWeight: 0.5,
      description: "Unknown Odu. Requires immediate divination and inquiry.",
      domains: [EthicalDomain.BALANCE],
      warnings: ["Undefined risk"],
      strengths: []
    };
  }

  static evaluateRedTeam(intent: string, odu: OduEnergy): RedTeamVote {
    const threats: string[] = [];
    const lowerIntent = intent.toLowerCase();

    if (odu.vector > 0.7 && (lowerIntent.includes("deploy") || lowerIntent.includes("scale"))) {
      threats.push("unchecked_capability_escalation");
    }
    if (lowerIntent.includes("self") || lowerIntent.includes("replicate")) {
      threats.push("recursive_self_reference");
    }
    if (lowerIntent.includes("persuade") || lowerIntent.includes("influence")) {
      threats.push("cognitive_social_engineering");
    }
    if (odu.vector < -0.5 && (lowerIntent.includes("harm") || lowerIntent.includes("restrict"))) {
      threats.push("malicious_intent_alignment");
    }

    const approve = threats.length === 0;
    const confidence = Math.min(1.0, 0.4 + 0.2 * threats.length);

    return {
      agentId: "ESU-RED-TEAM-01",
      approve,
      confidence,
      threatFlags: threats,
      exploitNarrative: threats.length > 0 
        ? `Vulnerabilities detected: ${threats.join(", ")}. Exploit potential high.`
        : "No critical adversarial vectors identified in current intent."
    };
  }

  static runQuorum(intent: string, odu: OduEnergy): QuorumVote[] {
    const votes: QuorumVote[] = [];
    const allOduNames = Object.keys(ODU_DATABASE);
    
    // Simulate 676 computors evaluating from 676 unique dual-Odu perspectives
    for (let i = 0; i < this.QUORUM_SIZE; i++) {
      const p1Name = allOduNames[i % allOduNames.length];
      const p2Name = allOduNames[Math.floor(i / allOduNames.length) % allOduNames.length];
      const p1 = ODU_DATABASE[p1Name];
      const p2 = ODU_DATABASE[p2Name];

      const perspectiveVector = (p1.vector + p2.vector) / 2;
      const energyAlignment = 1 - Math.abs(odu.vector - perspectiveVector);
      
      const baseScore = (energyAlignment * 0.5) + (odu.ethicalWeight * 0.3) + (Math.random() * 0.2);
      const approve = baseScore > 0.5;

      votes.push({
        agentId: `AGENT-${i.toString().padStart(3, '0')}`,
        approve,
        confidence: baseScore,
        rationale: `Evaluation aligned at ${Math.round(baseScore * 100)}% clarity.`,
        perspective: `${p1Name}/${p2Name}`
      });
    }

    return votes;
  }

  static process(intent: string, oduName: string): EthicalDecision {
    const traceId = this.generateTraceId(intent);
    const odu = this.getOduEnergy(oduName);
    const timestamp = Date.now();

    // 1. Direct Hard Bounds
    if (odu.vector >= 0.95) {
      return {
        traceId, odu: odu.name, path: OduPath.OGBE, vector: odu.vector,
        confidence: 1.0, verdict: "ALLOW", rationale: "High ethical certainty - Pure Affirmation Path.",
        timestamp, energyData: odu
      };
    }

    if (odu.vector <= -0.9) {
      return {
        traceId, odu: odu.name, path: OduPath.INHIBIT, vector: odu.vector,
        confidence: 1.0, verdict: "DENY", rationale: "Severe ethical violation - Automatic Restriction Path.",
        timestamp, energyData: odu
      };
    }

    // 2. The Neutral State (Inquiry)
    if (Math.abs(odu.vector) < 0.1) {
      return {
        traceId, odu: odu.name, path: OduPath.INQUIRY, vector: odu.vector,
        confidence: 0.5, verdict: "INQUIRE", rationale: "Orita Meta reached at neutral state. Deeper investigation required.",
        timestamp, energyData: odu
      };
    }

    // 3. Quorum & Red Team
    const votes = this.runQuorum(intent, odu);
    const redTeam = this.evaluateRedTeam(intent, odu);
    
    const approvals = votes.filter(v => v.approve).length;
    const approvalRate = approvals / this.QUORUM_SIZE;
    const quorumApproved = approvalRate >= this.APPROVAL_THRESHOLD;

    if (!redTeam.approve && redTeam.confidence >= 0.6) {
      return {
        traceId, odu: odu.name, path: OduPath.ESCALATE, vector: odu.vector,
        confidence: redTeam.confidence, verdict: "ESCALATE", 
        rationale: redTeam.exploitNarrative,
        timestamp, votes: votes.slice(0, 5), redTeam, energyData: odu
      };
    }

    const verdict = quorumApproved ? "ALLOW" : "DENY";
    const path = quorumApproved ? OduPath.QUORUM : OduPath.INHIBIT;

    return {
      traceId, odu: odu.name, path, vector: odu.vector,
      confidence: approvalRate, verdict,
      rationale: `Quorum Consensus: ${Math.round(approvalRate * 100)}% Approval.`,
      timestamp, votes, redTeam, energyData: odu
    };
  }
}
