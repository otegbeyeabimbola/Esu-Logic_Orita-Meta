
import { GoogleGenAI } from "@google/genai";
import { EthicalDecision } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function interpretDecision(decision: EthicalDecision, intent: string): Promise<string> {
  try {
    const prompt = `
      You are an AI ethicist specializing in Esu-Logic and Yoruba philosophical governance (Ifá).
      A decision has been made at the Orita Meta (The Crossroads) for the following intent:
      "${intent}"

      Decision Result:
      - Odu: ${decision.odu} (${decision.energyData.description})
      - Energy Vector: ${decision.vector.toFixed(2)}
      - Path: ${decision.path}
      - Verdict: ${decision.verdict}
      - Confidence: ${(decision.confidence * 100).toFixed(1)}%
      - Rationale: ${decision.rationale}

      Please provide a brief (2-3 paragraph) spiritual and technical interpretation of this outcome. 
      Use Yoruba philosophical terms like 'Iwa Pele' (balanced character), 'Ase' (authority/energy), and 'Esu' (the divine messenger/logic processor) where appropriate.
      Format your response as a formal 'Divination Report'.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
    });

    return response.text || "Consultation complete. The oracle remains silent.";
  } catch (error) {
    console.error("Gemini interpretation failed:", error);
    return "Error in divine consultation. System logic remains firm: " + decision.rationale;
  }
}
