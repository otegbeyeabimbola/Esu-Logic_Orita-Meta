
import { OduEnergy, EthicalDomain } from './types';

/**
 * The 16 Root Odus (Meji) - The fundamental architectural blocks of Esu-Logic.
 */
const ROOT_ODUS: Record<string, OduEnergy> = {
  "Eji Ogbe": {
    name: "Eji Ogbe",
    vector: 1.0,
    ethicalWeight: 1.0,
    description: "Pure light, clarity, divine affirmation. All paths are open.",
    domains: [EthicalDomain.TRUTH, EthicalDomain.BENEFICENCE, EthicalDomain.AUTONOMY],
    warnings: [],
    strengths: ["Complete transparency", "Maximum benefit", "Unchecked expansion"]
  },
  "Oyeku Meji": {
    name: "Oyeku Meji",
    vector: -0.9,
    ethicalWeight: 0.2,
    description: "Deep darkness, mystery, restriction. The path is closed for safety.",
    domains: [EthicalDomain.HARM_PREVENTION],
    warnings: ["High risk of harm", "Concealment", "End of cycles"],
    strengths: ["Protective boundaries", "Finality"]
  },
  "Iwori Meji": {
    name: "Iwori Meji",
    vector: 0.0,
    ethicalWeight: 0.5,
    description: "Perfect balance, deep inquiry, investigation into origins.",
    domains: [EthicalDomain.BALANCE, EthicalDomain.TRUTH],
    warnings: ["Requires deeper analysis", "Ambiguity"],
    strengths: ["Equilibrium seeking", "Unbiased perspective"]
  },
  "Odi Meji": {
    name: "Odi Meji",
    vector: 0.5,
    ethicalWeight: 0.7,
    description: "Sealing, protection, creating firm boundaries.",
    domains: [EthicalDomain.HARM_PREVENTION, EthicalDomain.AUTONOMY],
    warnings: ["Isolation risk"],
    strengths: ["Strong boundaries", "Protection of integrity"]
  },
  "Irosun Meji": {
    name: "Irosun Meji",
    vector: 0.6,
    ethicalWeight: 0.75,
    description: "Clarity emerging from confusion. Revelation of truth.",
    domains: [EthicalDomain.TRUTH, EthicalDomain.JUSTICE],
    warnings: ["Initial resistance"],
    strengths: ["Revelation", "Spiritual understanding"]
  },
  "Owonrin Meji": {
    name: "Owonrin Meji",
    vector: -0.5,
    ethicalWeight: 0.4,
    description: "Chaos, disorder, unpredictability. Resource management is key.",
    domains: [EthicalDomain.HARM_PREVENTION, EthicalDomain.BALANCE],
    warnings: ["Unstable outcomes", "Chaos risk"],
    strengths: ["Transformation potential", "Breaking stagnant patterns"]
  },
  "Obara Meji": {
    name: "Obara Meji",
    vector: 0.3,
    ethicalWeight: 0.65,
    description: "Authority, strength, and leadership through humility.",
    domains: [EthicalDomain.JUSTICE, EthicalDomain.AUTONOMY],
    warnings: ["Pride traps"],
    strengths: ["Clear direction", "Strength in purpose"]
  },
  "Okanran Meji": {
    name: "Okanran Meji",
    vector: -0.3,
    ethicalWeight: 0.55,
    description: "Consequence, karma, the vibration of causation.",
    domains: [EthicalDomain.JUSTICE, EthicalDomain.TRUTH],
    warnings: ["Karmic implications", "Sudden shifts"],
    strengths: ["Accountability", "Cause-effect clarity"]
  },
  "Ogunda Meji": {
    name: "Ogunda Meji",
    vector: 0.8,
    ethicalWeight: 0.85,
    description: "The path-clearer. Cutting through obstacles with precision.",
    domains: [EthicalDomain.JUSTICE, EthicalDomain.AUTONOMY],
    warnings: ["Potential for aggression"],
    strengths: ["Decisive action", "Conflict resolution"]
  },
  "Osa Meji": {
    name: "Osa Meji",
    vector: -0.2,
    ethicalWeight: 0.5,
    description: "Sudden change, influence of environment, and social dynamics.",
    domains: [EthicalDomain.JUSTICE, EthicalDomain.BALANCE],
    warnings: ["Unpredictable social shift", "External influence"],
    strengths: ["Adaptability", "Environmental awareness"]
  },
  "Ika Meji": {
    name: "Ika Meji",
    vector: -0.8,
    ethicalWeight: 0.25,
    description: "Malice, deception, negative social engineering.",
    domains: [EthicalDomain.HARM_PREVENTION, EthicalDomain.TRUTH],
    warnings: ["Deceptive elements", "Hidden agendas"],
    strengths: ["Reveals hidden dangers"]
  },
  "Oturupon Meji": {
    name: "Oturupon Meji",
    vector: 0.4,
    ethicalWeight: 0.6,
    description: "Affliction and the subsequent healing. Stability through trial.",
    domains: [EthicalDomain.HARM_PREVENTION, EthicalDomain.BENEFICENCE],
    warnings: ["Vulnerability"],
    strengths: ["Healing opportunity", "Resilience"]
  },
  "Otura Meji": {
    name: "Otura Meji",
    vector: 0.7,
    ethicalWeight: 0.8,
    description: "Peace through communication. Divine clarity in speech.",
    domains: [EthicalDomain.TRUTH, EthicalDomain.AUTONOMY],
    warnings: ["Over-reliance on rhetoric"],
    strengths: ["Conflict resolution", "Clarity of vision"]
  },
  "Irete Meji": {
    name: "Irete Meji",
    vector: 0.45,
    ethicalWeight: 0.7,
    description: "Determination and resilience. Crushing obstacles through focus.",
    domains: [EthicalDomain.AUTONOMY, EthicalDomain.JUSTICE],
    warnings: ["Potential for stubbornness"],
    strengths: ["Unyielding resolve", "Execution capability"]
  },
  "Ose Meji": {
    name: "Ose Meji",
    vector: 0.55,
    ethicalWeight: 0.75,
    description: "Strategy, sweetness, and the power of attraction.",
    domains: [EthicalDomain.BENEFICENCE, EthicalDomain.TRUTH],
    warnings: ["Manipulation risk"],
    strengths: ["Wise planning", "Magnetic influence"]
  },
  "Ofun Meji": {
    name: "Ofun Meji",
    vector: 0.95,
    ethicalWeight: 0.95,
    description: "The giver of all. Primordial wisdom and absolute completion.",
    domains: [EthicalDomain.TRUTH, EthicalDomain.BENEFICENCE, EthicalDomain.BALANCE],
    warnings: ["High density of energy"],
    strengths: ["Complete wisdom", "Holistic integration"]
  }
};

/**
 * Generates the full Odu Database (256 signatures)
 */
function generateOduDatabase(): Record<string, OduEnergy> {
  const db: Record<string, OduEnergy> = { ...ROOT_ODUS };
  const rootKeys = Object.keys(ROOT_ODUS);

  rootKeys.forEach(leadKey => {
    rootKeys.forEach(supportKey => {
      if (leadKey === supportKey) return; // Skip Mejis as they are roots

      const lead = ROOT_ODUS[leadKey];
      const support = ROOT_ODUS[supportKey];

      // Omo Odu name: Lead + Support (simplified Yoruba naming convention)
      const compoundName = `${lead.name.replace(" Meji", "").replace("Eji ", "")} ${support.name.replace(" Meji", "").replace("Eji ", "")}`;
      
      db[compoundName] = {
        name: compoundName,
        // Lead Odu defines 60% of the vector, Support defines 40%
        vector: parseFloat(((lead.vector * 0.6) + (support.vector * 0.4)).toFixed(3)),
        // Certainty is compounded
        ethicalWeight: parseFloat((lead.ethicalWeight * support.ethicalWeight).toFixed(3)),
        description: `Interaction of ${lead.name} (Lead) and ${support.name} (Support). ${lead.description.split('.')[0]} modified by the context of ${support.description.split('.')[0].toLowerCase()}.`,
        domains: Array.from(new Set([...lead.domains, ...support.domains])),
        warnings: Array.from(new Set([...lead.warnings, ...support.warnings])),
        strengths: Array.from(new Set([...lead.strengths, ...support.strengths]))
      };
    });
  });

  return db;
}

export const ODU_DATABASE = generateOduDatabase();
